//
// Created by Greg LaKomski on 2/8/19.
//


#include<iostream>
#include<cmath>
#include<cstdio>
#include <vector>
class Solution{

 private:

 std::vector<int> mergeCountInv(std::vector<int> a, std::vector<int> b, int & numInv) {
   auto outsize = a.size() + b.size();
   std::vector<int> out(outsize, 0);
    
            ................... your code here  ................
  
   return out;

  }


 public:


  std::vector<int> cntInv(std::vector<int> input, int & numInv){

         .............. your code here ...................//

  }

};