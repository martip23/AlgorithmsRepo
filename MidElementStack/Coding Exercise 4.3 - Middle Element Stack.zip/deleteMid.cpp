//
// Created by Greg LaKomski on 2/21/19.
//


#include<iostream>
#include<cmath>
#include<cstdio>
#include<stack>

class DeleteMid{

 public:

  void deleteMid(std::stack<int> &mystack, int n, int curr=0){

                  // If stack is empty or all items
                  // are traversed
   
   //...........code

                  // Remove current item
    
   // .......... code

                  // Remove other items
                  
   // .......... code

                  // Put all items back except middle
   // .......... code


  }
};