#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <utility>
#include <float.h>
#include <random>
#include <ctime>
#include "ClosestPair.cpp"


int main () {
   return 0;
}